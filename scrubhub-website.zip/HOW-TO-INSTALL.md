# ScrubHub Marketing Website: How to Install

These are plain HTML, CSS and JavaScript files, so there's nothing to build. They go into your ScrubHub app's `public` folder. Your React app, logins, Supabase and Stripe stay exactly as they are.

## What's in the zip

```
public/
├── _redirects          ← tells Netlify which page to show at each address
├── robots.txt          ← tells Google which pages to show in search
├── sitemap.xml         ← list of marketing pages for Google
└── site/
    ├── index.html      → proscrubhub.com/
    ├── features.html   → /features
    ├── pricing.html    → /pricing
    ├── industries.html → /industries
    ├── contact.html    → /contact  (contact form)
    ├── thanks.html     → /thanks   (shown after the form is sent)
    ├── terms.html      → /terms    (DRAFT)
    ├── privacy.html    → /privacy  (DRAFT)
    ├── site.css        ← all the styling
    ├── site.js         ← menu, price toggle, logged-in redirect
    └── pricing-config.js ← YOUR PRICES: edit them here
```

## Step 1: Add the files to your project

Use **Option A** if your Netlify site is connected to a GitHub repo, and **Option B** if it isn't.

### Option A: GitHub (Netlify deploys automatically)
1. Open your ScrubHub repo on github.com and go into the `public` folder. It's the folder that already has `manifest.webmanifest` and the `icons` folder.
2. Click **Add file → Upload files**.
3. Drag in the **`site` folder**, `robots.txt` and `sitemap.xml` from the zip.
4. **`_redirects`:**
   - If `public/_redirects` **doesn't exist** yet, upload the one from the zip.
   - If it **already exists**, open it, click the pencil (edit), and paste the lines between `# ---- ScrubHub marketing site` and `# ---- end marketing site ----` at the **very top**. Keep your existing `/* /index.html 200` line **last**.
5. Click **Commit changes**. Netlify builds and deploys on its own.

### Option B: No GitHub (manual drag-and-drop deploy)
1. In Netlify, go to **Deploys**, open your latest published deploy, and click **Download** to get the current site as a zip.
2. Unzip it. Copy the `site` folder, `robots.txt`, `sitemap.xml` and `_redirects` into the **top level** of that unzipped folder, next to `index.html`. If a `_redirects` file is already there, merge it as described in step 4 above.
3. Drag the whole folder onto the **Deploys** page in Netlify.

> **Using `netlify.toml` instead of `_redirects`?** That's fine. Netlify reads `_redirects` first, so just add the file as-is.

## Step 2: Turn on the contact form
In Netlify: **Site configuration → Forms → Enable form detection**, then deploy again. Messages will show up under **Forms** in Netlify, and you can turn on email alerts there. The free tier covers about 100 messages a month.

## Step 3: Check it
- Open `proscrubhub.com` while logged out. You should see the new home page.
- `proscrubhub.com/login` should look exactly the same as before.
- Log in, then go back to `proscrubhub.com`. You should be taken straight into the app. The installed phone app works the same way, so employees and clients won't land on the sales page.

## Before you promote it
- [ ] **Prices:** edit `site/pricing-config.js`, and the `"price"` numbers in the JSON-LD block near the top of `index.html` and `pricing.html`.
- [ ] **Charging for plans isn't connected yet.** The "Start free trial" buttons go to your current free `/signup` page (they add `?plan=pro&billing=monthly` so you can use it later). Taking subscription payments and enforcing team-member limits needs to be built in the app with Stripe Billing.
- [ ] **Email:** the site lists `hello@proscrubhub.com`. Set up that mailbox or forwarding (your domain is on Squarespace), or find and replace it with an email you already use.
- [ ] **Founder quote:** on the home page (search for "I built ScrubHub"). Make sure it sounds like you.
- [ ] **Testimonials:** the home page has an empty "Customer stories coming soon" box. Replace it with real quotes from real customers once you have them.
- [ ] **Terms and Privacy** are drafts. Get them reviewed or replaced before you take paying customers.
- [ ] Submit `https://proscrubhub.com/sitemap.xml` in Google Search Console.

## Editing later
Every page is a normal HTML file. Open it, change the words, save and redeploy. Colors and fonts live in `site/site.css` and match your app (teal `#0E9F8E`, Plus Jakarta Sans).
